3D Semantic Segmentation with Submanifold Sparse Convolutional Networks, CVPR 2018
SSCN-FCN A (k=1) network

Put the labeled dataset nyu_depth_v2_labeled.mat (2.8 GB) from http://cs.nyu.edu/~silberman/datasets/nyu_depth_v2.html, 
and the train/test split file splits.mat (2.6 kB) from http://cs.nyu.edu/~silberman/projects/indoor_scene_seg_sup.html into data/ and run data/prepare_data.py
