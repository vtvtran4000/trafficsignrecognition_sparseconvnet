# Copyright 2016-present, Facebook, Inc.
# All rights reserved.
#
# This source code is licensed under the BSD-style license found in the
# LICENSE file in the root directory of this source tree.

import numpy as np
import torch, torch.utils.data
import glob, math, os
import scipy, scipy.ndimage
import sparseconvnet as scn
import PIL
import pickle
import matplotlib.pyplot as plt
import random
import cv2
from torch.utils.data.dataset import Dataset
from torch.utils.data import DataLoader
import torchvision.transforms as transforms
from torchvision.utils import make_grid
import torch.utils.data.sampler as sampler
from torch import nn, optim
import torch.nn.functional as F
%matplotlib inline

if not os.path.exists('pickle/'):
    print('Downloading data ...')
    os.system('bash download_and_split_data.sh')

# Load pickled data
training_file = "train.p"
validation_file = "valid.p"
testing_file = "test.p"

with open(training_file, mode='rb') as f:
    train = pickle.load(f)
with open(validation_file, mode='rb') as f:
    valid = pickle.load(f)
with open(testing_file, mode='rb') as f:
    test = pickle.load(f)

X_train, y_train = train['features'], train['labels']
X_valid, y_valid = valid['features'], valid['labels']
X_test, y_test = test['features'], test['labels']

categories=["0", "1", "2", "3","4", "5", "6", "7","8", "9", "10", "11","12", "13", "14", "15",
           "16", "17", "18", "19","20", "21", "22", "23","24", "25", "26", "27","28", "29", "30",
            "31", "32", "33", "34","35", "36", "37", "38","39", "40", "41", "42"]
classes=["Speed limit (20km/h)", "Speed limit (30km/h)", "Speed limit (50km/h)", "Speed limit (60km/h)",
         "Speed limit (70km/h)", "Speed limit (80km/h)", "End of speed limit (80km/h)", "Speed limit (100km/h)",
         "Speed limit (120km/h)", "No passing", "No passing for vechiles over 3.5 metric tons", "Right-of-way at the next intersection",
         "Priority road", "Yield", "Stop", "No vechiles","Vechiles over 3.5 metric tons prohibited", 
         "No entry", "General caution", "Dangerous curve to the left","Dangerous curve to the right", 
         "Double curve", "Bumpy road", "Slippery road","Road narrows on the right", "Road work", 
         "Traffic signals", "Pedestrians","Children crossing", "Bicycles crossing", "Beware of ice/snow",
         "Wild animals crossing", "End of all speed and passing limits", "Turn right ahead", "Turn left ahead",
         "Ahead only", "Go straight or right", "Go straight or left", "Keep right","Keep left", "Roundabout mandatory",
         "End of no passing", "End of no passing by vechiles over 3.5 metric tons"]
nClasses=[210, 2220, 2250, 1410, 1980, 1860, 420, 1440, 1410, 1470, 2010, 1320, 2100, 2160, 780, 630, 420,
         1110, 1200, 210, 360, 330, 390, 510, 270, 1500, 600, 240, 540, 270, 450, 780, 240, 689, 420, 1200,
         390, 210, 2070, 300, 360, 240, 240]
classOffsets=np.cumsum([0]+nClasses)

class PickledDataset(Dataset):
    def __init__(self, file_path, transform=None):
        with open(file_path, mode='rb') as f:
            data = pickle.load(f)
            self.features = data['features']
            self.labels = data['labels']
            self.count = len(self.labels)
            self.transform = transform
        
    def __getitem__(self, index):
        feature = self.features[index]
        if self.transform is not None:
            feature = self.transform(feature)
        return (feature, self.labels[index])

    def __len__(self):
        return self.count

class WrappedDataLoader:
    def __init__(self, dl, func):
        self.dl = dl
        self.func = func

    def __len__(self):
        return len(self.dl)

    def __iter__(self):
        batches = iter(self.dl)
        for b in batches:
            yield (self.func(*b))


def init(c,resolution=50,sz=50*8+8,batchSize=43):
    globals()['categ']=c
    globals()['resolution']=resolution
    globals()['batchSize']=batchSize
    globals()['spatialSize']=torch.LongTensor([sz]*3)
    if categ==-1:
        print('All categories: 50 classes')
        globals()['nClassesTotal']=int(classOffsets[-1])
    else:
        print('categ ',categ,classes[categ])
        globals()['nClassesTotal']=int(nClasses[categ])

def train():
    train_dataset = PickledDataset(training_file, transform=transforms.ToTensor())
    d = DataLoader(train_dataset, batch_size=64, shuffle=True)

    print(len(d))
    def merge(tbl):
        xl_=[]
        xf_=[]
        y_=[]
        categ_=[]
        mask_=[]
        classOffset_=[]
        nClasses_=[]
        nPoints_=[]
        np_random=np.random.RandomState([x[-1] for x in tbl])
        for _, xl, y, categ, classOffset, nClasses, idx in tbl:
            m=np.eye(3,dtype='float32')
            m[0,0]*=np_random.randint(0,2)*2-1
            m=np.dot(m,np.linalg.qr(np_random.randn(3,3))[0])
            xl=np.dot(xl,m)
            xl+=np_random.uniform(-1,1,(1,3)).astype('float32')
            xl=np.floor(resolution*(4+xl)).astype('int64')
            xf=np.ones((xl.shape[0],1)).astype('float32')
            xl_.append(xl)
            xf_.append(xf)
            y_.append(y)
            categ_.append(np.ones(y.shape[0],dtype='int64')*categ)
            classOffset_.append(classOffset)
            nClasses_.append(nClasses)
            mask=np.zeros((y.shape[0],nClassesTotal),dtype='float32')
            mask[:,classOffset:classOffset+nClasses]=1
            mask_.append(mask)
            nPoints_.append(y.shape[0])
        xl_=[np.hstack([x,idx*np.ones((x.shape[0],1),dtype='int64')]) for idx,x in enumerate(xl_)]
        return {'x':  [torch.from_numpy(np.vstack(xl_)),torch.from_numpy(np.vstack(xf_))],
                'y':           torch.from_numpy(np.hstack(y_)),
                'categ':       torch.from_numpy(np.hstack(categ_)),
                'classOffset': classOffset_,
                'nClasses':    nClasses_,
                'mask':        torch.from_numpy(np.vstack(mask_)),
                'xf':          [x[0] for x in tbl],
                'nPoints':     nPoints_}
    return torch.utils.data.DataLoader(d,batch_size=batchSize, collate_fn=merge, num_workers=10, shuffle=True)

def valid():
    valid_dataset = PickledDataset(validation_file, transform=transforms.ToTensor())
    d = DataLoader(valid_dataset, batch_size=64, shuffle=False)
    print(len(d))
    def merge(tbl):
        xl_=[]
        xf_=[]
        y_=[]
        categ_=[]
        mask_=[]
        classOffset_=[]
        nClasses_=[]
        nPoints_=[]
        np_random=np.random.RandomState([x[-1] for x in tbl])
        for _, xl, y, categ, classOffset, nClasses, idx in tbl:
            m=np.eye(3,dtype='float32')
            m[0,0]*=np_random.randint(0,2)*2-1
            m=np.dot(m,np.linalg.qr(np_random.randn(3,3))[0])
            xl=np.dot(xl,m)
            xl+=np_random.uniform(-1,1,(1,3)).astype('float32')
            xl=np.floor(resolution*(4+xl)).astype('int64')
            xl_.append(xl)
            xf=np.ones((xl.shape[0],1)).astype('float32')
            xf_.append(xf)
            y_.append(y)
            categ_.append(np.ones(y.shape[0],dtype='int64')*categ)
            classOffset_.append(classOffset)
            nClasses_.append(nClasses)
            mask=np.zeros((y.shape[0],nClassesTotal),dtype='float32')
            mask[:,classOffset:classOffset+nClasses]=1
            mask_.append(mask)
            nPoints_.append(y.shape[0])
        xl_=[np.hstack([x,idx*np.ones((x.shape[0],1),dtype='int64')]) for idx,x in enumerate(xl_)]
        return {'x':  [torch.from_numpy(np.vstack(xl_)),torch.from_numpy(np.vstack(xf_))],
                'y':           torch.from_numpy(np.hstack(y_)),
                'categ':       torch.from_numpy(np.hstack(categ_)),
                'classOffset': classOffset_,
                'nClasses':    nClasses_,
                'mask': torch.from_numpy(np.vstack(mask_)),
                'xf':          [x[0] for x in tbl],
                'nPoints':     nPoints_}
    return torch.utils.data.DataLoader(d,batch_size=batchSize, collate_fn=merge, num_workers=10, shuffle=True)
